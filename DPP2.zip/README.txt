			=============WARNING=============
	Everything you see in the folders except python files is not mine,
Everything except Python files is taken from the source project. 
Link to the original project: https://github.com/RoosterDragon/Desktop-Ponies/releases

	In general, this project was a joke at first, but then when I wrote more than 500 lines,
I realized that it should be released, congratulations, it was released, I was able to write an emulator in python,
of course it's not perfect, but in future updates it will be redone.
(This project was written in python for 3 months starting from the end of August 2025)
The text in the python program is written in Russian (#Text , """Text""" , print("Text")),
in the future they will be adapted to the language in the program settings.

Also read the  "information about ponies.txt"
The startup application is called "DPP2.py"